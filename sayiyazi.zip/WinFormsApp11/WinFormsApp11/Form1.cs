/****************************************************************************
** SAKARYA �N�VERS�TES�
** B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
** B�LG�SAYAR M�HEND�SL��� B�L�M�
** NESNEYE DAYALI PROGRAMLAMA DERS�
** 2021-2022 BAHAR D�NEM�
**
** �DEV NUMARASI..........:2.�dev
** ��RENC� ADI............:Bu�ra Ba�aran
** ��RENC� NUMARASI.......:G211210015
** DERS�N ALINDI�I GRUP...:2.��retim B grubu
****************************************************************************/
namespace WinFormsApp11
{
    public partial class Form1 : Form
    {
        private void txtBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;

            }
            else
            {
                e.Handled = false;
            }
        }
        public Form1()//form1 metodu
        {
            InitializeComponent();//ilk i�lemler
            
        }
        public void Form1_Load(object sender, EventArgs e)
        {      
            BackColor = Color.Tan;
            TextBox txtBox1 = new TextBox();//txtBox1 olu�turulur
            txtBox1.Top = 175;//txtBox1 in konumunu belirler.
            txtBox1.Left = 205;//""      
            txtBox1.BackColor = Color.Black;//txtBox1 in arka plan rengini siyah yapar
            txtBox1.ForeColor = Color.Red;//txtBox1 in yaz� rengini k�rm�z� yapar
            txtBox1.Focus();//program �al��t���nda imle� otomatik olarak txtBox1 e gider
            this.Controls.Add(txtBox1);//txtBox1 i ekler.
            Label label1 = new Label();//label olu�turur
            label1.Text = "";//labela bo� de�er atar
            label1.Top = 250;//label �n konumunu ayarlar
            label1.Left = 100;//""
            label1.Width = 600;//label�n geni�li�ini ayarlar
            label1.ForeColor = Color.Green;//label�n yaz� rengini ye�il yapar
            label1.BackColor = Color.Pink;//label�n arka plan rengini pembe yapar
            this.Controls.Add(label1);//label ekler.
            Label label2 = new Label();
            label2.AutoSize = false;
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.Text = "SAYIYI YAZIYA �EV�RME PROGRAMI";
            label2.Top = 50;
            label2.Left = 150;
            label2.Width = 300;
           
            label2.ForeColor = Color.Red;
            this.Controls.Add(label2);
            Label label3 = new Label();
            label3.Text = "SONU�:";
            label3.TextAlign=ContentAlignment.MiddleCenter;
            label3.Top = 250;
            label3.Left = 15;
            label3.ForeColor= Color.Red;
            label3.BackColor = Color.Black;
            this.Controls.Add(label3);
            Label label4 = new Label();
            label4.Text = "Say� giriniz:";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            label4.Top = 175;
            label4.Left = 50;
            label4.ForeColor = Color.Red;
            label4.BackColor = Color.Black;
            this.Controls.Add(label4);
            Label label5 = new Label();
            label5.Text = "kuru� i�lemleriniz i�in virg�l kullan�n�z!!";          
            label5.TextAlign = ContentAlignment.MiddleCenter;
            label5.Top = 125;
            label5.Left = 50;
            label5.ForeColor = Color.Green;
            label5.BackColor = Color.Black;
            label5.Width = 270;
            this.Controls.Add(label5);
            Label label6 = new Label();
            label6.Text = "ve iki basamak �eklinde yaz�n�z!!!";
            label6.Top = 150;
            label6.Left = 50;
            label6.Width = 230;
            label6.ForeColor = Color.Green;
            label6.BackColor = Color.Black;
            this.Controls.Add(label6);

            Button button1 = new Button();//buton olu�turur
            button1.Text = "Yaz�ya�evir";//butonda Yaz�y��evir yazd�r�r
            button1.Top = 325;//butonun konumunu ayarlar
            button1.Left = 275;
            button1.BackColor = Color.Black;//butonun arka plan rengini siyah yapar
            button1.ForeColor = Color.Red;//butonun yaz� rengini k�rm�z� yapar
            button1.Height = 50;//butonun y�ksekli�ini ayarlar
            button1.Width = 100;//butonun geni�li�ini ayalar
           
            AcceptButton = button1;//enter a bas�ld���nda butona bas�lm�� olur
            this.Controls.Add(button1);//buton ekler
            button1.Click += new EventHandler(Olustur);//buton ile yap�lan i�lemleri e�le�tirir
            string a;

            void Olustur(object sender, EventArgs e)
            {
                string metin = txtBox1.Text;
                Console.WriteLine(metin + "\n");
                string liste = "ABC�DEFG�H�IJKLMNO�PRS�TU�VYZ"
                               + "abc�defg�hi�jklmno�prs�tu�vyz";

                int sayac = 0;
                for (int i = 0; i < metin.Length; i++)
                {
                    //karakter katarkter kontrol ediyoruz.
                    if (liste.Contains(metin[i]))
                    {
                        sayac++;
                    }
                }
                if (sayac == 0)
                {

                    char aranan = ',';
                    int virgulKontrol;
                    virgulKontrol = txtBox1.Text.IndexOf(aranan);//virg�l var m� yok mu varsa ka��nc� s�rada bulur
                    if (virgulKontrol == -1)//virg�l yoksa
                    {
                        if (txtBox1.Text.Length <= 5)//basamak kontrol�
                        {
                            string yaziyaCevir(decimal tutar)
                            {
                                string sTutar = tutar.ToString("F2").Replace('.', ','); // Replace('.',',') ondal�k ayrac�n�n . olma durumu i�in            
                                string lira = sTutar.Substring(0, sTutar.IndexOf(',')); //tutar�n tam k�sm�n� al�r

                                string yazi = "";
                                string kurus = sTutar.Substring(sTutar.IndexOf(',') + 1, 2);//tutar�n kuru� k�sm�n� al�r

                                string[] birler = { "", " B�R", " �K�", " ��", " D�RT", " BE�", " ALTI", " YED�", " SEK�Z", " DOKUZ"};
                                string[] onlar = { "", " ON", " Y�RM�", " OTUZ"," KIRK", " ELL�", " ALTMI�", " YETM��", " SEKSEN", " DOKSAN" };
                                string[] binler = { " KATR�LYON ", " TR�LYON ", " M�LYAR ", " M�LYON ", " B�N", "" }; //KATR�LYON'un �n�ne ekleme yap�larak art�rabilir.

                                int grupSayisi = 6; //say�daki 3'l� grup say�s�. katrilyon i�i 6. (1.234,00 daki grup say�s� 2'dir.)


                                lira = lira.PadLeft(grupSayisi * 3, '0'); //say�n�n soluna 0 eklenerek say� (grup say�s� x 3) basamak yap�l�r.            
                                string grupDeger;
                                int i = 0;
                                while (i < grupSayisi * 3) //say� 3'erli gruplar halinde ele al�n�yor.
                                {
                                    grupDeger = "";

                                    if (lira.Substring(i, 1) != "0")
                                        grupDeger += birler[Convert.ToInt32(lira.Substring(i, 1))] + " Y�Z"; //y�zler                

                                    if (grupDeger == " B�R Y�Z") //biry�z d�zeltiliyor.
                                        grupDeger = " Y�Z";

                                    grupDeger += onlar[Convert.ToInt32(lira.Substring(i + 1, 1))]; //onlar

                                    grupDeger += birler[Convert.ToInt32(lira.Substring(i + 2, 1))]; //birler                

                                    if (grupDeger != "") //binler
                                        grupDeger += binler[i / 3];

                                    if (grupDeger == " B�R B�N") //birbin d�zeltiliyor.
                                        grupDeger = " B�N";

                                    yazi += grupDeger;
                                    i += 3;
                                }

                                if (yazi != "")//TL VAR �SE TL YAZDIR
                                    yazi += " TL ";

                                int yaziUzunlugu = yazi.Length;

                                if (kurus.Substring(0, 1) != "0") //kuru� onlar
                                    yazi += onlar[Convert.ToInt32(kurus.Substring(0, 1))];

                                if (kurus.Substring(1, 1) != "0") //kuru� birler
                                    yazi += birler[Convert.ToInt32(kurus.Substring(1, 1))];

                                if (yazi.Length > yaziUzunlugu)
                                    yazi += " Kr.";
                                else
                                    yazi += "S�f�r Kr.";
                                return yazi;
                            }
                            label1.Text = yaziyaCevir(Convert.ToDecimal(txtBox1.Text));
                        }
                        else
                        {
                            MessageBox.Show("girdi�iniz de�er 5 basamaktan b�y�k olamaz");
                        }
                    }
                    else if (virgulKontrol != -1)//virg�l varsa
                    {
                        if (txtBox1.Text.Length <= 8)
                        {
                            string yaziyaCevir(decimal tutar)
                            {
                                
                                string sTutar = tutar.ToString().Replace('.', ','); // Replace('.',',') ondal�k ayrac�n�n . olma durumu i�in
                                string kurus = sTutar.Substring(sTutar.IndexOf(',') + 1, 2);//tutar�n kuru� k�sm�n� al�r.
                                string TL = sTutar.Substring(0, sTutar.IndexOf(',')); //tutar�n tam k�sm�n� al�r.
                               
                                    
                                      string yazi = "";
                               
                               

                                    string[] birlerBasamak = { "", " B�R", " �K�", " �� ", " D�RT", " BE�", " ALTI", " YED�", " SEK�Z", " DOKUZ" };
                                    string[] onlarBasamak = { "", " ON", " Y�RM�", " OTUZ", " KIRK", " ELL�", " ALTMI�", " YETM��", " SEKSEN", " DOKSAN" };
                                    string[] binlerBasamak = { "KATR�LYON", "TR�LYON", "M�LYAR", "M�LYON", " B�N", "" };
                                    int UcluGrupSayisi = 6; //say�daki 3'l� grup say�s�d�r.
                                    TL = TL.PadLeft(UcluGrupSayisi * 3, '0'); //say�n�n soluna 0 eklenerek say� (grup say�s� x 3) basamak olur.            
                                    string grupDeger;
                                    for (int i = 0; i < UcluGrupSayisi * 3; i += 3) //say� 3'erli gruplar halinde ele al�n�yor.
                                    {
                                        grupDeger = "";

                                        if (TL.Substring(i, 1) != "0")
                                            grupDeger += birlerBasamak[Convert.ToInt32(TL.Substring(i, 1))] + " Y�Z"; //y�zler basama��               

                                        if (grupDeger == " B�R Y�Z") //biry�z d�zeltiliyor.
                                            grupDeger = " Y�Z";

                                        grupDeger += onlarBasamak[Convert.ToInt32(TL.Substring(i + 1, 1))]; //onlar basama��

                                        grupDeger += birlerBasamak[Convert.ToInt32(TL.Substring(i + 2, 1))]; //birler basama��         

                                        if (grupDeger != "") //binler basama��
                                            grupDeger += binlerBasamak[i / 3];

                                        if (grupDeger == " B�R B�N") //birbin d�zeltiliyor.
                                            grupDeger = " B�N";

                                        yazi += grupDeger;
                                    }

                                    if (yazi != "")
                                    {
                                        yazi += " TL ";
                                    }
                                    int yaziUzunlugu = yazi.Length;
                                    {
                                        if (kurus.Substring(0, 1) != "0") //kuru� onlar
                                            yazi += onlarBasamak[Convert.ToInt32(kurus.Substring(0, 1))];
                                    }
                                    if (kurus.Substring(1, 1) != "0") //kuru� birler
                                    {
                                        yazi += birlerBasamak[Convert.ToInt32(kurus.Substring(1, 1))];
                                    }
                                    if (yazi.Length > yaziUzunlugu)
                                    {
                                        yazi += " Kr.";
                                    }
                                    else
                                        yazi += "SIFIR Kr.";
                                    return yazi;
  
                            }
                            label1.Text = yaziyaCevir(Convert.ToDecimal(txtBox1.Text));
                        }
                        else
                        {
                            MessageBox.Show("girdi�iniz de�er 5 basamaktan b�y�k olamaz");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Sadece rakam giriniz!!!");
                }
            }
        }
    }
}
